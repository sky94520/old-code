#ifndef __BehaviorManager_H__
#define __BehaviorManager_H__
#include<string>
#include<unordered_map>
#include<vector>
#include<algorithm>
#include "SDL_Engine/SDL_Engine.h"
using namespace SDL;
using namespace std;

class MoveBehavior;
class EffectBehavior;
class GameScene;

enum MoveBehaviorType
{
	kMoveNoWayBehaviorType,//���˶�
	kMoveWithTileCollidedAndCanDropType,
	kMoveWithoutGravityType,//�������� ��ͼ����ײ�˶�
	kMoveOnlyWithVelocity,//�������ٶ��ƶ�
};
enum EffectBehaviorType
{
	kPlayerLevelUpEffectType,//mario����Ч��
	kPlayerCanHurtEnemyEffectType,//�Ե����Ǻ��Ч��
};
class BehaviorDelegate
{
public:
	virtual ~BehaviorDelegate(){}
	virtual bool isCollodedTile(const Rect&r,char dir)=0;
	virtual Point getGravity()const=0;
};
class BehaviorManager:public BehaviorDelegate
{
private:
	static BehaviorManager*m_pInstance;
	unordered_map<MoveBehaviorType,MoveBehavior*> m_moveBehaviors;
	//vector<MoveBehavior*> m_moveBehaviors;
	unordered_map<EffectBehaviorType,EffectBehavior*> m_effectBehaviors;
	GameScene*m_pGameScene;
private:
	BehaviorManager();
	~BehaviorManager();
public:
	static BehaviorManager*getInstance();
	void purge();
	void setGameScene(GameScene*scene);
	//�������ͻ�ȡ��Ӧ����Ϊ
	MoveBehavior*getMoveBehaviorByType(MoveBehaviorType type);
	MoveBehavior*getMoveBehaviorByType(const string&typeName);

	EffectBehavior*getEffectBehaviorByType(EffectBehaviorType type);
private:
	MoveBehavior*createMoveBehavior(MoveBehaviorType type);
	EffectBehavior*createEffectBehavior(EffectBehaviorType type);
	virtual bool isCollodedTile(const Rect&r,char dir);
	virtual Point getGravity()const;
};
#endif