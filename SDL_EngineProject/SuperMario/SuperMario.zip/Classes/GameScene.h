#ifndef __GameScene_H__
#define __GameScene_H__
#include "SDL_Engine/SDL_Engine.h"
#include "PlayerLayer.h"
#include "KeyEventLayer.h"
#include "MapLayer.h"
#include "ItemLayer.h"
#include "EnemyLayer.h"

using namespace SDL;
class Entity;
class Player;

class GameScene:public Scene
	,public PlayerLayerDelegate,public EventLayerDelegate,public MapLayerDelegate
	,public ItemLayerDelegate
{
private:
	MapLayer*m_pMapLayer;
	PlayerLayer*m_pPlayerLayer;
	KeyEventLayer*m_pEventLayer;
	ItemLayer*m_pItemLayer;
	EnemyLayer*m_pEnemyLayer;

	Point m_gravity;//����
public:
	GameScene();
	~GameScene();
	CREATE_FUNC(GameScene);
	bool init();
	virtual void update(float dt);
	//��ȡʵ���
	TMXLayer*getEntityLayer()const;
	Player*getPlayer()const;
public:
	void handleCollision(float dt);
	void handleCollisionBetweenPlayerAndItems(float dt);
	void handleCollisionBetweenPlayerAndEnemys(float dt);

	virtual int isCollidedTile(Rect r,char dir)const;
	virtual int isCollidedTile(const Rect&r,Entity*entity,char dir);
	virtual Point getGravity()const;
	ValueMap getTilePropertiesForGID(int gid);
private://delegate
	virtual Point getPlayerBornPos()const;
	virtual void keyPressed(EventType eventType);
	virtual void keyReleased(EventType eventType);
	virtual bool createObjectByTypeAndName(TMXObject*object);
	virtual void createEntityByTMXObject(TMXObject*object);
};
#endif