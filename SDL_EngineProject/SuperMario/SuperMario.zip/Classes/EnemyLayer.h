#ifndef __EnemyLayer_H__
#define __EnemyLayer_H__
#include<vector>
#include "SDL_Engine/SDL_Engine.h"
using namespace SDL;
using namespace std;
class Enemy;

class EnemyLayer:public Layer
{
private:
	vector<Enemy*> m_enemys;
public:
	EnemyLayer();
	~EnemyLayer();
	CREATE_FUNC(EnemyLayer);
	bool init();
	virtual void update(float dt);
	
	vector<Enemy*>& getEnemys();
	//��������
	void enemyBorn(TMXObject*object,Layer*layer);
private:
	bool isObsolete(Enemy*enemy);
};
#endif