#include "EffectBehavior.h"
#include "BehaviorManager.h"
#include "Item.h"
#include "Player.h"

EffectBehavior::EffectBehavior()
	:m_pDelegate(nullptr)
{
}
void EffectBehavior::setDelegate(BehaviorDelegate*pDelegate)
{
	m_pDelegate = pDelegate;
}
//---------------------------------PlayerLevelUpEffect----------------------------
void PlayerLevelUpEffect::performEffect(Item*item,Player*player)
{
	//������Ч
	if(item->isDying())
		return;
	player->levelUp();
}
void PlayerCanHurtEnemyEffect::performEffect(Item*item,Player*player)
{
	//������Ч
	if(item->isDying())
		return;
	player->canHurtEnemyWithInvulnearability();
}